const icons={shield:'<path d="M12 3 3 7v5c0 5 4 8 9 10 5-2 9-5 9-10V7Z"/><path d="m8 12 3 3 5-6"/>',wrench:'<path d="M15 6a5 5 0 0 0-6 6L3 18l3 3 6-6a5 5 0 0 0 6-6l-3 3-3-3 3-3Z"/>',bolt:'<path d="m13 2-9 12h7l-1 8 10-13h-7Z"/>',gear:'<circle cx="12" cy="12" r="5"/><path d="M12 2v4m0 12v4M2 12h4m12 0h4M5 5l3 3m8 8 3 3M5 19l3-3m8-8 3-3"/>',flag:'<path d="M5 22V3m0 1h14l-3 5 3 5H5"/>',home:'<path d="m3 10 9-7 9 7v11H3Z"/><path d="M9 21v-7h6v7"/>',book:'<path d="M12 5v16M3 4c4-1 7 0 9 2 2-2 5-3 9-2v15c-4-1-7 0-9 2-2-2-5-3-9-2Z"/>',chart:'<path d="M3 3v18h18M7 16v-5m5 5V6m5 10v-8"/>',play:'<path d="m8 5 12 7-12 7Z"/>',arrow:'<path d="M4 12h15m-6-6 6 6-6 6"/>',back:'<path d="M20 12H5m6-6-6 6 6 6"/>',check:'<path d="m5 12 4 4L19 6"/>',close:'<path d="m6 6 12 12M18 6 6 18"/>',sound:'<path d="M3 9h4l5-4v14l-5-4H3Zm13-1c3 2 3 6 0 8m3-11c5 4 5 10 0 14"/>',reset:'<path d="M3 11a9 9 0 1 1 3 8M3 4v7h7"/>',menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v1"/>',clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',lock:'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',download:'<path d="M12 3v12m-5-5 5 5 5-5M4 17v4h16v-4"/>'};
const I=(name,cls='')=>`<svg class="${cls}" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name]||icons.info}</svg>`;
const SCENE_IMAGES={
  hero:'images/hero-team.webp',
  ppe:'images/scene-prep.webp',
  bench:'images/scene-prep.webp',
  motor:'images/scene-motor.webp',
  height:'images/scene-height.webp',
  hammer:'images/scene-handtools.webp',
  wrench:'images/scene-handtools.webp',
  joint:'images/scene-joint.webp',
  electric:'images/scene-electric.webp',
  press:'images/scene-press.webp',
  crane:'images/scene-crane.webp',
  collapse:'images/scene-collapse.webp'
};
function scene(name){
  const src=SCENE_IMAGES[name]||SCENE_IMAGES.hero;
  const alt={
    hero:'Команда на производстве',
    ppe:'Подготовка рабочего места и СИЗ',
    bench:'Подготовка рабочего места и проходов',
    motor:'Изоляция энергии перед ремонтом',
    height:'Работы по высоте и опасная зона внизу',
    hammer:'Осмотр ручного инструмента',
    wrench:'Осмотр ручного инструмента',
    joint:'Совмещение элементов при сборке',
    electric:'Проверка электроинструмента',
    press:'Работа на сверлильном станке',
    crane:'Подвешенный груз и опасная зона',
    collapse:'Остановка работ при аварийной ситуации'
  }[name]||'Производственная сцена';
  return `<img class="scene-media" src="${src}" alt="${alt}" loading="lazy">`;
}
